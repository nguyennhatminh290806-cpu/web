<?php
// Chạy một lần từ dòng lệnh:  php install.php
// Tạo bảng, nạp tin mẫu và tài khoản quản trị. Đặt mật khẩu admin qua BM_ADMIN_PASS (nếu bỏ trống sẽ sinh ngẫu nhiên).
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Chỉ chạy bằng dòng lệnh.'); }
require __DIR__ . '/db.php';

$cfg = require __DIR__ . '/config.php';
if ($cfg['driver'] === 'sqlite') {
    @mkdir(dirname($cfg['sqlite']), 0775, true);
} else {
    // tạo database nếu chưa có
    $pdo0 = new PDO("mysql:host={$cfg['host']};port={$cfg['port']};charset=utf8mb4", $cfg['user'], $cfg['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $pdo0->exec("CREATE DATABASE IF NOT EXISTS `{$cfg['name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
}
$pdo = db();

if ($cfg['driver'] === 'sqlite') {
    $ddl = [
     'CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE, mat_khau TEXT NOT NULL, ho_ten TEXT NOT NULL, vai_tro TEXT NOT NULL DEFAULT "user")',
     'CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, slug TEXT NOT NULL UNIQUE, ten TEXT NOT NULL, mo_ta TEXT)',
     'CREATE TABLE IF NOT EXISTS articles (id INTEGER PRIMARY KEY AUTOINCREMENT, category_id INTEGER NOT NULL REFERENCES categories(id), tieu_de TEXT NOT NULL, tom_tat TEXT NOT NULL, noi_dung TEXT NOT NULL, tac_gia TEXT NOT NULL, luot_doc INTEGER NOT NULL DEFAULT 0, noi_bat INTEGER NOT NULL DEFAULT 0, ngay_dang TEXT NOT NULL)',
     'CREATE TABLE IF NOT EXISTS saved_articles (user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE, ngay_luu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (user_id, article_id))',
    ];
    foreach ($ddl as $q) $pdo->exec($q);
} else {
    // bỏ dòng CREATE DATABASE / USE trong schema.sql (đã xử lý ở trên)
    $sql = preg_replace('/^(CREATE DATABASE|USE) .*$/mi', '', file_get_contents(__DIR__ . '/schema.sql'));
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $q) $pdo->exec($q);
}

if ((int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn() > 0) {
    echo "Dữ liệu đã tồn tại, bỏ qua bước nạp mẫu.\n";
    exit(0);
}

$seed = json_decode(file_get_contents(__DIR__ . '/seed_data.json'), true);
$pdo->beginTransaction();
$ic = $pdo->prepare('INSERT INTO categories (slug, ten, mo_ta) VALUES (?,?,?)');
$ids = [];
foreach ($seed['categories'] as $c) { $ic->execute([$c['slug'], $c['ten'], $c['mo_ta']]); $ids[$c['slug']] = (int)$pdo->lastInsertId(); }
$ia = $pdo->prepare('INSERT INTO articles (category_id, tieu_de, tom_tat, noi_dung, tac_gia, luot_doc, noi_bat, ngay_dang) VALUES (?,?,?,?,?,?,?,?)');
foreach ($seed['articles'] as $a) {
    $ia->execute([$ids[$a['cat']], $a['tieu_de'], $a['tom_tat'], $a['noi_dung'], $a['tac_gia'], $a['luot_doc'], $a['noi_bat'], gmdate('Y-m-d H:i:s', time() - $a['phut_truoc'] * 60)]);
}
$pass = getenv('BM_ADMIN_PASS') ?: bin2hex(random_bytes(6));
$pdo->prepare('INSERT INTO users (email, mat_khau, ho_ten, vai_tro) VALUES (?,?,?,?)')
    ->execute(['admin@binhminh.vn', password_hash($pass, PASSWORD_DEFAULT), 'Ban biên tập', 'admin']);
$pdo->commit();
echo "Đã cài đặt xong.\nTài khoản quản trị: admin@binhminh.vn\nMật khẩu: $pass\n(Hãy ghi lại mật khẩu này.)\n";
