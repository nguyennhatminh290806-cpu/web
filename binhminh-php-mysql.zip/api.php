<?php
declare(strict_types=1);
require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax',
    'secure' => !empty($_SERVER['HTTPS'])]);
session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));

function out(array $d, int $code = 200): never { http_response_code($code); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
function fail(string $msg, int $code = 400): never { out(['error' => $msg], $code); }
function str(mixed $v, int $max): string { return mb_substr(trim((string)($v ?? '')), 0, $max); }

function me(): ?array {
    if (empty($_SESSION['uid'])) return null;
    $st = db()->prepare('SELECT id, email, ho_ten, vai_tro FROM users WHERE id = ?');
    $st->execute([$_SESSION['uid']]);
    return $st->fetch() ?: null;
}
function state(): array {
    $u = me(); $saved = [];
    if ($u) {
        $st = db()->prepare('SELECT article_id FROM saved_articles WHERE user_id = ? ORDER BY ngay_luu DESC');
        $st->execute([$u['id']]);
        $saved = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }
    return ['user' => $u ? ['email' => $u['email'], 'name' => $u['ho_ten'], 'role' => $u['vai_tro']] : null,
            'csrf' => $_SESSION['csrf'], 'saved' => $saved];
}
function article_row(array $r): array {
    return ['id' => (int)$r['id'], 'cat' => $r['slug'], 't' => $r['tieu_de'], 's' => $r['tom_tat'],
            'b' => array_values(array_filter(array_map('trim', explode("\n", $r['noi_dung'])), 'strlen')),
            'a' => $r['tac_gia'], 'v' => (int)$r['luot_doc'], 'f' => (int)$r['noi_bat'],
            'ts' => strtotime($r['ngay_dang'] . ' UTC') * 1000];
}
const ART_SQL = 'SELECT a.*, c.slug FROM articles a JOIN categories c ON c.id = a.category_id';

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$body = [];
if ($method === 'POST') {
    $tok = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals($_SESSION['csrf'], $tok)) fail('Phiên làm việc không hợp lệ, hãy tải lại trang.', 403);
    $body = json_decode(file_get_contents('php://input') ?: '[]', true);
    if (!is_array($body)) fail('Dữ liệu gửi lên không hợp lệ.');
}
function require_admin(): array {
    $u = me();
    if (!$u) fail('Bạn cần đăng nhập.', 401);
    if ($u['vai_tro'] !== 'admin') fail('Bạn không có quyền thực hiện thao tác này.', 403);
    return $u;
}

try {
    switch ($method . ' ' . $action) {
    case 'GET articles':
        $rows = db()->query(ART_SQL . ' ORDER BY a.ngay_dang DESC, a.id DESC')->fetchAll();
        out(['articles' => array_map('article_row', $rows)]);

    case 'GET me':
        out(state());

    case 'POST register':
        $email = strtolower(str($body['email'] ?? '', 120));
        $name = str($body['name'] ?? '', 80);
        $pass = (string)($body['password'] ?? '');
        if ($name === '') fail('Vui lòng nhập họ tên.');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Email không hợp lệ.');
        if (mb_strlen($pass) < 6 || strlen($pass) > 200) fail('Mật khẩu cần từ 6 ký tự.');
        $st = db()->prepare('SELECT 1 FROM users WHERE email = ?'); $st->execute([$email]);
        if ($st->fetch()) fail('Email này đã có tài khoản. Hãy đăng nhập.', 409);
        db()->prepare('INSERT INTO users (email, mat_khau, ho_ten, vai_tro) VALUES (?,?,?,?)')
            ->execute([$email, password_hash($pass, PASSWORD_DEFAULT), $name, 'user']);
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)db()->lastInsertId();
        out(state());

    case 'POST login':
        $_SESSION['fails'] = $_SESSION['fails'] ?? 0;
        if ($_SESSION['fails'] >= 5 && time() < ($_SESSION['lock'] ?? 0)) fail('Đăng nhập sai nhiều lần. Hãy thử lại sau ít phút.', 429);
        $email = strtolower(str($body['email'] ?? '', 120));
        $st = db()->prepare('SELECT id, mat_khau FROM users WHERE email = ?'); $st->execute([$email]);
        $u = $st->fetch();
        $ok = password_verify((string)($body['password'] ?? ''), $u['mat_khau'] ?? '$2y$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvali');
        if (!$u || !$ok) {
            if (++$_SESSION['fails'] >= 5) { $_SESSION['lock'] = time() + 300; $_SESSION['fails'] = 5; }
            fail('Email hoặc mật khẩu chưa đúng.', 401);
        }
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$u['id']; $_SESSION['fails'] = 0;
        out(state());

    case 'POST logout':
        $_SESSION = []; session_regenerate_id(true);
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
        out(state());

    case 'POST view':
        $id = (int)($body['id'] ?? 0);
        db()->prepare('UPDATE articles SET luot_doc = luot_doc + 1 WHERE id = ?')->execute([$id]);
        $st = db()->prepare('SELECT luot_doc FROM articles WHERE id = ?'); $st->execute([$id]);
        $v = $st->fetchColumn();
        if ($v === false) fail('Không tìm thấy bài viết.', 404);
        out(['v' => (int)$v]);

    case 'POST save':
        $u = me(); if (!$u) fail('Bạn cần đăng nhập để lưu bài.', 401);
        $id = (int)($body['id'] ?? 0);
        $st = db()->prepare('SELECT 1 FROM articles WHERE id = ?'); $st->execute([$id]);
        if (!$st->fetch()) fail('Không tìm thấy bài viết.', 404);
        $st = db()->prepare('SELECT 1 FROM saved_articles WHERE user_id = ? AND article_id = ?'); $st->execute([$u['id'], $id]);
        if ($st->fetch()) {
            db()->prepare('DELETE FROM saved_articles WHERE user_id = ? AND article_id = ?')->execute([$u['id'], $id]); $on = false;
        } else {
            db()->prepare('INSERT INTO saved_articles (user_id, article_id, ngay_luu) VALUES (?,?,?)')->execute([$u['id'], $id, gmdate('Y-m-d H:i:s')]); $on = true;
        }
        out(['on' => $on] + state());

    case 'POST create_article':
        require_admin();
        $slug = str($body['cat'] ?? '', 40);
        $t = str($body['t'] ?? '', 200); $s = str($body['s'] ?? '', 400);
        $a = str($body['a'] ?? '', 80) ?: 'Ban biên tập';
        $paras = array_values(array_filter(array_map('trim', explode("\n", str_replace("\r", '', (string)($body['b'] ?? '')))), 'strlen'));
        if ($t === '' || $s === '' || !$paras) fail('Vui lòng nhập đủ tiêu đề, tóm tắt và nội dung.');
        $nd = mb_substr(implode("\n", $paras), 0, 20000);
        $st = db()->prepare('SELECT id FROM categories WHERE slug = ?'); $st->execute([$slug]);
        $cid = $st->fetchColumn();
        if (!$cid) fail('Chuyên mục không tồn tại.');
        db()->prepare('INSERT INTO articles (category_id, tieu_de, tom_tat, noi_dung, tac_gia, luot_doc, noi_bat, ngay_dang) VALUES (?,?,?,?,?,0,1,?)')
            ->execute([$cid, $t, $s, $nd, $a, gmdate('Y-m-d H:i:s')]);
        $st = db()->prepare(ART_SQL . ' WHERE a.id = ?'); $st->execute([db()->lastInsertId()]);
        out(['article' => article_row($st->fetch())], 201);

    case 'POST delete_article':
        require_admin();
        $st = db()->prepare('DELETE FROM articles WHERE id = ?'); $st->execute([(int)($body['id'] ?? 0)]);
        if (!$st->rowCount()) fail('Không tìm thấy bài viết.', 404);
        out(['ok' => true]);

    default:
        fail('Yêu cầu không hợp lệ.', 404);
    }
} catch (Throwable $e) {
    error_log('Binh Minh API: ' . $e->getMessage());
    fail('Lỗi máy chủ. Vui lòng thử lại sau.', 500);
}
