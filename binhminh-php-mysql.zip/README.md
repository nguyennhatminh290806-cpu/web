# Báo điện tử Bình Minh (PHP + MySQL)

## Cấu trúc
- `index.html`: giao diện (ứng dụng một trang), gọi `api.php`
- `api.php`: API JSON (đăng ký, đăng nhập, bài viết, lưu bài, quản trị)
- `config.php`, `db.php`: cấu hình và kết nối PDO
- `schema.sql`: cấu trúc MySQL; `install.php`: tạo bảng, nạp tin mẫu, tạo tài khoản admin
- `seed_data.json`: tin mẫu

## Chạy bằng XAMPP
1. Bật Apache và MySQL trong XAMPP Control Panel.
2. Chép thư mục này vào `htdocs/binhminh`.
3. Mở terminal trong thư mục đó: `php install.php` (ghi lại mật khẩu admin in ra; hoặc đặt trước `BM_ADMIN_PASS=matkhau`).
4. Mở http://localhost/binhminh/index.html

Nếu MySQL không dùng root/không mật khẩu, đặt biến môi trường `BM_DB_USER`, `BM_DB_PASS`, `BM_DB_HOST`, `BM_DB_NAME` hoặc sửa `config.php`.
Có thể nhập `schema.sql` bằng phpMyAdmin, nhưng vẫn cần `php install.php` để nạp tin mẫu và tạo admin.

## Chạy nhanh không cần Apache
```
php install.php
php -S localhost:8000
```
Mở http://localhost:8000/index.html. (Không mở trực tiếp tệp HTML bằng `file://`.)
Thử bằng SQLite không cần MySQL: đặt `BM_DRIVER=sqlite` cho cả `install.php` và `php -S`.

## Bảo mật
Mật khẩu băm bằng `password_hash`; truy vấn dùng prepared statement; cookie phiên HttpOnly + SameSite; mã CSRF cho mọi thao tác ghi; quyền admin kiểm tra ở máy chủ. Khi triển khai thật: dùng HTTPS và tạo tài khoản MySQL riêng.
