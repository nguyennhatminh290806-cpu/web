<?php
// Cấu hình kết nối. Mặc định khớp XAMPP (MySQL user root, không mật khẩu).
// Khi triển khai thật, đặt biến môi trường hoặc sửa trực tiếp ở đây và KHÔNG dùng root.
$env = fn(string $k, string $d) => getenv($k) !== false ? getenv($k) : $d;
return [
    'driver' => $env('BM_DRIVER', 'mysql'),          // 'mysql' hoặc 'sqlite' (sqlite chỉ để thử nhanh)
    'host'   => $env('BM_DB_HOST', '127.0.0.1'),
    'port'   => $env('BM_DB_PORT', '3306'),
    'name'   => $env('BM_DB_NAME', 'binhminh'),
    'user'   => $env('BM_DB_USER', 'root'),
    'pass'   => $env('BM_DB_PASS', ''),
    'sqlite' => $env('BM_SQLITE', __DIR__ . '/data/binhminh.sqlite'),
];
