-- Cơ sở dữ liệu báo điện tử Bình Minh (MySQL / MariaDB)
CREATE DATABASE IF NOT EXISTS binhminh CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE binhminh;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(120) NOT NULL UNIQUE,
  mat_khau VARCHAR(255) NOT NULL,              -- mã băm password_hash()
  ho_ten VARCHAR(80) NOT NULL,
  vai_tro ENUM('user','admin') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(40) NOT NULL UNIQUE,
  ten VARCHAR(60) NOT NULL,
  mo_ta VARCHAR(200)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS articles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT NOT NULL,
  tieu_de VARCHAR(200) NOT NULL,
  tom_tat VARCHAR(400) NOT NULL,
  noi_dung TEXT NOT NULL,                      -- mỗi đoạn một dòng
  tac_gia VARCHAR(80) NOT NULL,
  luot_doc INT NOT NULL DEFAULT 0,
  noi_bat TINYINT(1) NOT NULL DEFAULT 0,
  ngay_dang DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (ngay_dang),
  FOREIGN KEY (category_id) REFERENCES categories(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS saved_articles (
  user_id INT NOT NULL,
  article_id INT NOT NULL,
  ngay_luu DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, article_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE
) ENGINE=InnoDB;
